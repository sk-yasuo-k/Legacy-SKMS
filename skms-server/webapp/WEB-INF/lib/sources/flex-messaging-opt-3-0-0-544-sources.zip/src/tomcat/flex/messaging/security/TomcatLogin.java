/*************************************************************************
 * 
 * ADOBE CONFIDENTIAL
 * __________________
 * 
 *  [2002] - [2007] Adobe Systems Incorporated 
 *  All Rights Reserved.
 * 
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated
 * and its suppliers and may be covered by U.S. and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 */
package flex.messaging.security;

import java.security.Principal;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

/**
 * Interface to code in the Tomcat valve.  Why is this needed?  Because Tomcat has a classloader system
 * where code in a valve does not appear in the classloader that is used for servlets.  There is a commons
 * area that both valves and servlets share, however, which is where this interface needs to be placed.
 *
 * JAR NOTE: this class is not in flex-messaging.jar but rather flex-tomcat-common.jar
 *
 * @author Brian Deitte
 * @author Matt Chotin
 */
public interface TomcatLogin
{
    public Principal login(String username, String password, HttpServletRequest request);
    public boolean authorize(Principal principal, List roles);
    public boolean logout(HttpServletRequest request);
}
