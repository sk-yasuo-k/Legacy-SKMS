package flex.messaging.services.http;

import org.apache.commons.httpclient.protocol.Protocol;

import flex.messaging.FlexConfigurable;

/**
 * Implementations of the ProtocolFactory interface allow the developer to
 * customize how the HTTP Proxy Service communicates with a 3rd party endpoint.
 * ProtocolFactory extends FlexConfigurable to allow for properties to be
 * provided directly in the services configuration.
 * <p>
 * An example of a custom protocol might be to provide client certificates
 * for two-way SSL authentication for a specific destination.
 * </p>
 * <p>
 * Implementations of this interface must provide a default, no-args
 * constructor.
 * </p>
 * 
 * @author Peter Farland
 */
public interface ProtocolFactory extends FlexConfigurable
{
    /**
     * Returns a custom implementation of Apache Commons
     * HTTPClient's Protocol interface.
     * 
     * @return An implementation of org.apache.commons.httpclient.protocol.Protocol.
     */
    Protocol getProtocol();
}
